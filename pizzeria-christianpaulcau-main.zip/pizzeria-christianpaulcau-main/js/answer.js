/**
 * Your answers to HW#4 goes here. 
 */
import { pizza } from "./util.js";


function createUserID() {
    var uid = create_UUID();
}

function createPizza() {
    var pizza = new Pizza();
    var toppings = gettoppings();
    var name = getname();
    var type = gettype();
}

function createOrder() {
    var size = getsize();
}

function displayCart() {
    htmlview = '<div class = "card-group">';
    const Pizza = require('/js/util.js');
    htmlView += '<div class = "card-group">' +
        '<img src="' + pizza.src + '"class="card-img-top" alt="">' +
        '<div class="card-body">' +
        '<h6 class="card-title">' + pizza.name + '</h6>' +
        '<p class="card-text">' + pizza.description + '</p>' +
        '</div>' +
        '<div class= "card-footer">' +
        '<button type="button" id="addBtn" onclick=addTocart("' + pizza.id + ')">Add to Cookie</button>' +
        '</div>' +
        '</div>';

}


function addTocart(uid) {
    let cart = getCookie("cart")
    if (!cart) {
        cart = [{ "uid":""}]
    }

}

function buildShoppingCart() {
    cartElement = $("#shoppingCart");

    cartHtmlView = '<table class = "table table-striped">' +
        '<thead>' +
        '<tr>' +
        '<th>Item</th>' +
        '<th>Qty</th>' +
        'th>Unit Price</th>' +
        '<th>Total</th>' +
        '<tr>' +
        '</thead>' +
        '<tbody>'
    let cart = getCookie("cart")

    if (!cart) {
        return
    }

    cart = JSON.parse(cart)

    cart.forEach(p => {
        pizza = PizzaOrderItem(pizza.ud);
        '<tr>' +
        '<td>' + pizza.name + '</td>' +
            '<td>' + pizza.type + '</td>'++
            '<td>' + pizza.toppings + '</td>' +
            '<td>' + parseFloat(pizza.price) * parseInt(p.toppings) + '</td>' +
            '</tr>';

    })
    '<tr>' +
    '<td>' + pizza.name + '</td>' +
        '<td colspan="3">Sub-Total</td>' +
        '<td>' + subTotal + '</td>' +
        '</tr>';
}